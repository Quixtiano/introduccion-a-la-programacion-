#include <stdio.h>
#include <stdlib.h>
#include<math.h>

int main(int argc, char *argv[])
{
    const float pi=3.1416;
    float radio, altura, vol,hip,a;
    printf("Inserte el radio de la circunferencia:\n "); scanf("%f",&radio);
    printf("Inserte la altura del cono:\n "); scanf("%f",&altura);
  
  vol=(pi*radio*radio*altura)/3;
  printf("El volumen del cono es: %.2f\n",vol);
  hip=sqrt(radio*radio+altura*altura);
  a=pi*radio*hip+pi*radio*radio;
  printf("El area del cono es de: %.2f\n",a);
   vol=radio*radio*altura*(1/3);
  system("PAUSE");	
  return 0;
}
