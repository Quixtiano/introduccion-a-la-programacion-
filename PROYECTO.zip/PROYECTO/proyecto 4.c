#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int seg,min,hor,st;
    printf("Inserte los segundos para la convercion: "); scanf("%d",&seg);
    
    st=((seg/60)<60)? seg:(seg%60);
    
    min=((seg/60)>60)? ((seg%3600)/60):0;  
    
    hor=((seg/3600)>60)? 0:(seg/3600); 
     
      printf("%d Horas\n%d Minutos\n%d Segundos\n",hor,min,st);
      
    
  system("PAUSE");	
  return 0;
}
