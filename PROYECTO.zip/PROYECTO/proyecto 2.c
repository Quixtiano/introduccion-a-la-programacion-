#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float pi, yar,cm,m,pul;
  
  printf("pies: ");
  scanf("%f",&pi);
  
  yar=pi/3;
  pul=pi*12;
  cm=2.54*pul; 
  m=cm/100;
  
  printf("pulgadas:%.2f\nyardas:%.2f\ncm:%.2f\nm:%.2f\n",pul,yar,cm,m);
  
  
  system("PAUSE");	
  return 0;
}
