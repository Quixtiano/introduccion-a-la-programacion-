#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int x,y,a,b, rest;
  printf("inserte el valor de x: ");
  scanf("%d",&x);
  printf("inserte el valor de y: ");
  scanf("%d",&y);
  printf("inserte el valor de a: ");
  scanf("%d",&a);
  printf("inserte el valor de b: ");
  scanf("%d",&b);
  
  
  rest=(x+y)*(x+y)*(a-b);
  printf("%d\n",rest);
  
  
  system("PAUSE");	
  return 0;
}
