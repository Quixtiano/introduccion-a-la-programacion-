#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int din, di,cin,dos,pe;
    
    printf("Inserte la cantidad de dinero a la cual se le hara la conversion: "); scanf("%d",&din);
  di=din/10;
  cin=(din%10)/5;
  dos=((din%10)%5)/2;
  pe=((din%10)%5)%2;
  
  printf("la conversion equivale a:\n%d monedas de 10\n%d monedas de 5\n%d monedas de 2\n%d monedas de 1",di,cin,dos,pe);
  
  system("PAUSE");	
  return 0;
}
