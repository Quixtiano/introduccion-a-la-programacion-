#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{ 
    float cen,fa,gra, im;
    char ban;
    printf("Ingrese los grados a convertir y C si es celsius o F si es fareheit (la letra en mayuscula): "); scanf("%f%c",&gra,&ban);
    
   im=(ban=='C')? (gra*1.8)+32:(gra-32)/1.8;;
    printf("la conversion da como resultado: %.2f",im);
    
  system("PAUSE");	
  return 0;
}
