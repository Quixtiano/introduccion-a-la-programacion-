#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[])
{
    const float g=9.81, pi=3.1416;
    
  float d,h,pre,den,vol;
  char ti;
  
  printf("inserte d si es disel o a si es agua: ");
  scanf("%c",&ti);
  
  printf("inserte el diametro de la circunferencia: ");
  scanf("%f",&d); 
  
  printf("Inserte la presion ejercida (en bars): ");
   scanf("%f",&pre);
   
den=(ti=='d')? 820:1000;
h=(pre*100000)/(den*g);

  vol=pi*((d/2)*(d/2))*h;
  
  printf("la altura del pozo es de: %.2f",h);
  printf("\nel volumen del pozo es de: %.2f ", vol);
  system("PAUSE");	
  return 0;
}
