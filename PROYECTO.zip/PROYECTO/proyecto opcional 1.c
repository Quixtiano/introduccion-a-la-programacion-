#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    float vol,in,re;
  printf("Inserte el voltaje y la intensidad: "); scanf("%f%f",&vol,&in);
  re=vol/in;
  printf("la resistencia sera de: %.2f \n",re);
  system("PAUSE");	
  return 0;
}
