#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int i,j,aux,burbuja[10],suma[10],bur[12];
	int matriz[10][12]={
	{90,90,40,60,20,80,10,10,30,70,50,25},
	{100,80,50,10,60,40,100,40,80,70,100,56},
	{70,90,60,20,80,50,20,60,30,70,110,60},
	{50,60,50,30,20,80,50,40,20,70,200,70},
	{90,90,60,40,80,70,60,40,30,50,10,40},
	{40,10,50,40,30,90,30,80,80,60,90,86},
	{100,40,20,50,10,100,90,80,100,70,130,120},
	{70,10,90,70,50,30,70,60,20,50,40,89},
	{40,30,40,70,10,100,20,20,70,20,90,66},
	{10,60,100,50,60,40,50,100,90,20,15,30},
	};
	for(i=0;i<10;i++)
	{
		printf("\n");
		for(j=0;j<12;j++)
		{
			printf("%d\t",matriz[i][j]);
		}
	}
	for(i=0;i<10;i++)
	{
		suma[i]=0;
	}
	
	for(i=0;i<10;i++)
	{
		for(j=0;j<12;j++)
		{
			suma[i]+=matriz[i][j];
		}
	}
	
	printf("\n");
/*	for(i=0;i<10;i++)
	{
		printf("%d\t",suma[i]);
	}
	*/
	
	
	for(i=0;i<10;i++)
	{
		burbuja[i]=suma[i];
	}
		printf("\n");
/*	for(i=0;i<10;i++)
	{
		printf("%d\t",burbuja[i]);
	}
*/
	for(i=0;i<10;i++)
	{
		for(j=0;j<10;j++)
		{
			if(burbuja[j]>burbuja[j+1])
			{
				aux=burbuja[j];
				burbuja[j]=burbuja[j+1];
				burbuja[j+1]=aux;
			}
		}
	}
	printf("\n");
/*	for(i=0;i<10;i++)
	{
		printf("\n %d",burbuja[i]);
	}
*/	
	for(i=0;i<10;i++)
	{
		if(burbuja[9]==suma[i])
		{
		switch(i)
		{
			case 0: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Sonora");
			break;
			case 1: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Aguascalientes");
			break;
			case 2: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Oaxaca");
			break;
			case 3: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Colima");
			break;
			case 4: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es chihuahua");
			break;
			case 5: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es San Luis Potosi");
			break;
			case 6: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Durango");
			break;
			case 7: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Veracruz");
			break;
			case 8: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Yucatan");
			break;
			case 9: printf("\nEl estado que tuvo menor registro de lluvias durante el ultimo anio es Tabasco");
			break;
		
		}
		}
	}

	
	for(i=0;i<10;i++)
	{
		if(burbuja[0]==suma[i])
		{
		switch(i)
		{
			case 0: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Sonora");
			break;
			case 1: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Aguascalientes");
			break;
			case 2: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Oaxaca");
			break;
			case 3: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Colima");
			break;
			case 4: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es chihuahua");
			break;
			case 5: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es San Luis Potosi");
			break;
			case 6: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Durango");
			break;
			case 7: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Veracruz");
			break;
			case 8: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Yucatan");
			break;
			case 9: printf("\nEl estado que tuvo mayor registro de lluvias durante el ultimo anio es Tabasco");
			break;
		
		}
		}
	}

	int mes[12];
	
	for(i=0;i<12;i++)
	{
		mes[i]=matriz[1][i];
		bur[i]=matriz[1][i];
	}
	printf("\n");
	
	
	for(i=0;i<12;i++)
	{
		printf("%d\t",mes[i]);
	}
	
	
	
	for(i=0;i<12;i++)
	{
		for(j=0;j<12;j++)
		{
		if(bur[j]>bur[j+1])
			{
				aux=bur[j];
				bur[j]=bur[j+1];
				bur[j+1]=aux;
			}	
		}
	}
	printf("\n");
	for(i=0;i<12;i++)
	{
		printf("%d\t",bur[i]);
	}
	
	
	for(i=0;i<12;i++)
	{
		if(bur[9]==mes[i])
		{
			
					switch(i)
					{
						case 0: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es enero");
						break;
						case 1: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es febrero");
						break;
						case 2: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es marzo");
						break;
						case 3:printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es  abril");
						break;
						case 4: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es mayo ");
						break;
						case 5: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es junio");
						break;
						case 6: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es julio");
						break;
						case 7: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es agosto");
						break;
						case 8: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es septiembre");
						break;
						case 9: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es octubre");
						break;
						case 10: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es noviembre");
						break;
						case 11: printf("\nEl mes que tuvo mayor registro de lluvias del estado de Aguascalientes del �ltimo a�o es dciembre");
						break;

					}
		
			
			
		}
	}
	return 0;
}
