#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int i,j,con1,con2,g;
	char c;
	int matriz[5][6]={{1,2,1,1,0,0},
	{1,0,1,1,0,1},
	{1,0,1,1,0,1},
	{1,0,0,0,0,1},
	{1,1,0,1,1,1}};
	
	printf("LABERINTO\n"); 
	
		con1=0;
	con2=1;
	

	

	while(matriz[0][5]==0)
	{
		if((g==1)||(con1<0)||(con1>5))
		{
		matriz[0][5]=1;
		printf("PERDISTE");
		
		}
		else
		{	printf("\n");
				for(i=0;i<5;i++)
				{
					for(j=0;j<6;j++) 
					{
						printf("%d  ",matriz[i][j]);
					}
				printf("\n");
				}
			
			printf("introduce A para avanzar arriba, B para avanzar abajo, D para avanzar a la derecha e I para avanzar a la izquierda: ");
			scanf("%c%*c",&c);
			
			
			switch(c)
			{
				case 'a': 
				matriz[con1][con2]=0;
				con1--;
				if(matriz[con1][con2]==1)
				{
					printf("perdiste\n");
					g=1;
				}
				else
				{
					matriz[con1][con2]=2;
				}
				break;
				case 'b' :
					matriz[con1][con2]=0;
					con1++;
					if(matriz[con1][con2]==1)
					{
						printf("perdiste\n");
						g=1;
					}		
					else
					{
						matriz[con1][con2]=2;
					}	
				break;
				case 'd' :
					matriz[con1][con2]=0;
					con2++;
					
					if(matriz[con1][con2]==1)
					{
						printf("perdiste");
						g=1;
					}
					else
					{
						matriz[con1][con2]=2;
					}
					break;
				case 'i' :
					matriz[con1][con2]=0;
					con2--;
					if(matriz[con1][con2]==1)
					{
						printf("perdiste");
						g=1;
					} 
					
					else
					{
						matriz[con1][con2]=2;
					}
					break;
			}
			if(matriz[0][5]==2)
			{
				
				for(i=0;i<5;i++)
				{
					for(j=0;j<6;j++) 
					{
						printf("%d  ",matriz[i][j]);
					}
				printf("\n");
				}
				
				printf("GANASTE\n");
			}
			
			
		}
	}
	
	system("PAUSE");
	return 0;
}
