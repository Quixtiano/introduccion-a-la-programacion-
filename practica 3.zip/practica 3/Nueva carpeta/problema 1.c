#include <stdio.h>
#include <stdlib.h>
#include<time.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	srand(time(NULL));
	int matriz[100], suma[10],i,j,k;
	
	for(i=0;i<100;i++)
	{
		matriz[i]=1+rand()%10;
	}
	for(i=0;i<100;i++)
	{
		printf("%d\t",matriz[i]);
	}
	for(i=0;i<10;i++)
	{
		suma[i]=0;
	}
	for(i=0;i<100;i++)
	{
		switch(matriz[i])
		{
			case 1:
				suma[0]+=1;
				break;
			case 2:
				suma[1]+=1;
				break;
			case 3:
				suma[2]+=1;
				break;
			case 4:
				suma[3]+=1;
				break;
			case 5:
				suma[4]+=1;
				break;
			case 6:
				suma[5]+=1;
				break;
			case 7:
				suma[6]+=1;
				break;
			case 8:
				suma[7]+=1;
				break;
			case 9:
				suma[8]+=1;
				break;
			case 10:
				suma[9]+=1;
				break;
		}
	}
	printf("\n");
	for(i=0;i<10;i++)
	{
		j=i+1;
		printf("\nla frecuencia del valor %d es: %d",j,suma[i]);
	}
	
	
	
	return 0;
}
