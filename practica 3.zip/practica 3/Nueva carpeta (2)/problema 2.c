#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int vector[10], i, j;
	
	for(i=0;i<10;i++)
	{
		printf("Inserte un valor para el vector: " ); scanf("%d",&vector[i]);
	}
	printf("vector inicial\n");
	
	for(i=0;i<10;i++)
	{
		printf("%d\t",vector[i]);
	}
	
	for(i=0;i<10;i++)
	{
		for(j=i+1;j<10;j++)
		{
			if(vector[i]==vector[j])
			{
				vector[j]=0;
			}
		}
	}
	printf("\nvector final\n");
	
	for(i=0;i<10;i++)
	{
		printf("%d\t",vector[i]);
	}
	
	return 0;
}
