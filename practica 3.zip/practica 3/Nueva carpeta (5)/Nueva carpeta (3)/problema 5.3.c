#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	//determinante 3*3
	int i,j,n;
	printf("DETERMINANTE DE UNA MATRIZ 3*3 2*2 y 1*1");
	printf("\ninserte el numero de filas que tendra la matriz (1,2,3): "); scanf("%d",&n);
	if(n>3)
	{
	
		
			printf("el numero dado excede");
			
	}
	else
	{
		int matriz[n][n],det;
	
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				printf("inserte el valor de la matriz en la fila %d columna %d:   ",i,j);
				scanf("%d",&matriz[i][j]);
			}
		}
		printf("\nMATRIZ");
		for(i=0;i<n;i++)
		{
			printf("\n");
			for(j=0;j<n;j++)
			{
				printf("%d\t",matriz[i][j]);
			}
		}
		
		if(n==1)
		{
			det=matriz[n][n];
		
		}
		if(n==2)
		{
			det=matriz[0][0]*matriz[1][1]-matriz[1][0]*matriz[0][1];
			
		}
		if(n==3)
		{
			det=matriz[0][0]*matriz[1][1]*matriz[2][2]+matriz[0][1]*matriz[1][2]*matriz[2][0]+matriz[0][2]*matriz[1][0]*matriz[2][1]-matriz[0][1]*matriz[1][0]*matriz[2][2]-matriz[0][0]*matriz[1][2]*matriz[2][1]-matriz[0][2]*matriz[1][1]*matriz[2][0];
		}
	
	
			printf("el valor de la determinante es: %d",det);
	
		}
		
		
		
	
	
	
	return 0;
}
