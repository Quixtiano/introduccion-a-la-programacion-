#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	printf("Inversa de la matriz\n ");
	int matriz[3][3];
	int i,j;
	float inv[3][3],det;
	int ma[3][3];
	
		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
			{
				printf("inserte el valor de la matriz en la fila %d columna %d:   ",i,j);
				scanf("%d",&matriz[i][j]);
			}
		}
		printf("\nMATRIZ\n");
			for(i=0;i<3;i++)
		{
			printf("\n");
			for(j=0;j<3;j++)
			{
				printf("%d\t",matriz[i][j]);
			}
		}
	
	det=matriz[0][0]*matriz[1][1]*matriz[2][2]+matriz[0][1]*matriz[1][2]*matriz[2][0]+matriz[0][2]*matriz[1][0]*matriz[2][1]-matriz[0][1]*matriz[1][0]*matriz[2][2]-matriz[0][0]*matriz[1][2]*matriz[2][1]-matriz[0][2]*matriz[1][1]*matriz[2][0];
printf("\n el determinante es %f\n",det);
		ma[0][0]=matriz[1][1]*matriz[2][2]-matriz[1][2]*matriz[2][1];
		ma[1][0]=(matriz[1][0]*matriz[2][2]-matriz[1][2]*matriz[2][0])*(-1);
		ma[2][0]=matriz[1][0]*matriz[2][1]-matriz[1][1]*matriz[2][0];
		ma[0][1]=(matriz[0][1]*matriz[2][2]-matriz[0][2]*matriz[2][1])*(-1);
		ma[1][1]=matriz[0][0]*matriz[2][2]-matriz[0][2]*matriz[2][0];
		ma[2][1]=matriz[0][0]*matriz[2][1]-matriz[0][1]*matriz[2][0]*(-1);
		ma[0][2]=matriz[0][1]*matriz[1][2]-matriz[0][2]*matriz[1][1];
		ma[1][2]=matriz[0][0]*matriz[1][2]-matriz[0][2]*matriz[1][0]*(-1);
		ma[2][2]=matriz[0][0]*matriz[1][1]-matriz[0][1]*matriz[1][0];
		
		for(i=0;i<3;i++)
		{
			printf("\n");
			
			for(j=0;j<3;j++)
			
			printf("%d\t",ma[i][j]);
		}
	i=(1/det);
	printf("\n%d\n",i);		
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			inv[i][j]=ma[i][j]*(1/det);
		}
	}
	for(i=0;i<3;i++)
		{
			printf("\n");
			
			for(j=0;j<3;j++)
			
			printf("%f\t",inv[i][j]);
		}	
	
	return 0;
}
